## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
library(myRpackage)
library(ggplot2) 

## -----------------------------------------------------------------------------
data_chn <- read_hdi(system.file("extdata", "hdro_indicators_chn.csv", package = "myRpackage"))
data_irl <- read_hdi(system.file("extdata", "hdro_indicators_irl.csv", package = "myRpackage"))
data_jpn <- read_hdi(system.file("extdata", "hdro_indicators_jpn.csv", package = "myRpackage"))

print(head(data_chn))
print(head(data_irl))
print(head(data_jpn))

## -----------------------------------------------------------------------------
summary(data_chn)
summary(data_irl)
summary(data_jpn)

## -----------------------------------------------------------------------------
plot(data_chn)
plot(data_irl)
plot(data_jpn)

